import logging

logger = logging.getLogger("sqlaudit")
